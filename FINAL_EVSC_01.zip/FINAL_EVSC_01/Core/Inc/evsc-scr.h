/*
 * /* user code begin header */
/**
  ******************************************************************************
  * @file    stm32f4xx_hal_conf_template.h
  * @author  mcd application team
  * @brief   hal configuration template file.
  *          this file should be copied to the application folder and renamed
  *          to stm32f4xx_hal_conf.h.
  ******************************************************************************
  * @attention
  *
  * copyright (c) 2017 stmicroelectronics.
  * all rights reserved.
  *
  * this software is licensed under terms that can be found in the license file
  * in the root directory of this software component.
  * if no license file comes with this software, it is provided as-is.
  *
  ******************************************************************************
  */
/* user code end header */

#ifndef inc_evsc_scr_h_
#define inc_evsc_scr_h_


void pwmdata(uint64_t secc_set_com);
void pwmdataevse(uint64_t inc_evsc_com);
void msg1_evsc(uint64_t inc_evsc_com);
void authentication (uint64_t inc_evsc_com);
void mess5th(uint64_t inc_evsc_com);
void txmsg9(uint64_t inc_evsc_com);
void maxvolt(uint64_t inc_evsc_com);
void evready(uint64_t inc_evsc_com) ;

// struct of secc to evsecc - pwm info

typedef struct    //0x02
{
	uint8_t seccpwmduty; //seccpwminfo.evsepwmduty
	uint16_t seccpwmfrequency; //seccpwminfo.evsepwmfrequency
	uint16_t seccpwmvoltage; //seccpwminfo.evsepwmvoltage
	uint8_t reserved3;
	uint8_t reserved4;
	uint8_t reserved5;
}pwm;

// this is from the  evse to secc

typedef struct{// evse = 0x03
	    uint8_t evsepwmduty; //evsepwminfo.evsepwmduty
		uint16_t evsepwmfrequency; //evsepwminfo.evsepwmfrequency
		uint16_t evsepwmvoltage; //evsepwminfo.evsepwmvoltage
		uint8_t reserved3;
		uint8_t reserved4;
		uint8_t reserved5;
}evsepwm;


// process 2

// evse message for check status code

// process this data

typedef struct    //0x04
{
	uint8_t evseprocessing_authentication :1;//evsemsg1.evseprocessing_authentication
	uint8_t evseprocessing_chargeparam :1;//evsemsg1.evseprocessing_chargeparam
	uint8_t evseprocessing_cablecheck :1;//evsemsg1.evseprocessing_cablecheck
	uint8_t reserved :5;

	uint8_t evseisolationstatus; //evsemsg1.evseisolationstatus
	uint8_t evsestatuscode; //evsemsg1.evsestatuscode
	uint32_t reserved4;

}msg1;


// message from the hlc check 0x03

typedef struct{     //0x03

	 uint8_t comm_slac :1; //seccprocess.comm_slac
	 uint8_t comm_sdp :1; //seccprocess.comm_sdp
	 uint8_t reserved :6;

	 uint8_t hlc_supportedappprotocolreq :1; //seccprocess.hlc_supportedappprotocolreq
	 uint8_t hlc_sessionsetupreq :1; //seccprocess.hlc_sessionsetupreq
	 uint8_t hlc_sevicediscoveryreq :1; //seccprocess.hlc_sevicediscoveryreq
	 uint8_t reserved2 :1;
	 uint8_t hlc_servicepaymentselectionreq:1; //seccprocess.hlc_servicepaymentselectionreq
	 uint8_t hlc_contractauthenticationreq :1; //seccprocess.hlc_contractauthenticationreq
	 uint8_t hlc_chargeparameterdiscoveryreq :1;
//seccprocess.hlc_chargeparameterdiscoveryreq
	 uint8_t hlc_cablecheckreq :1; //seccprocess.hlc_cablecheckreq

	 uint8_t hlc_prechargereq :1; //seccprocess.hlc_prechargereq
	 uint8_t hlc_powerdeliveryreq :1; //seccprocess.hlc_powerdeliveryreq
	 uint8_t reserved3 :1;
	 uint8_t hlc_currentdemandreq :1; //seccprocess.hlc_currentdemandreq
	 uint8_t hlc_weldingdetectionreq :1; //seccprocess.hlc_weldingdetectionreq
	 uint8_t hlc_sessionstopreq :1; //seccprocess.hlc_sessionstopreq
	 uint8_t reserved4 :1;
	 uint8_t reserved5 :1;

	 uint8_t reserve6;

	 uint8_t hlc_supportedappprotocolres :1;
//seccprocess.hlc_supportedappprotocolres
	 uint8_t hlc_sessionsetupres :1; //seccprocess.hlc_sessionsetupres
	 uint8_t hlc_sevicediscoveryres :1; //seccprocess.hlc_sevicediscoveryres
	 uint8_t reserved7 :1;
	 uint8_t hlc_servicepaymentselectionres :1; //seccprocess.hlc_servicepaymentselectionres
	 uint8_t hlc_contractauthenticationres :1; //seccprocess.hlc_contractauthenticationres
	 uint8_t hlc_chargeparameterdiscoveryres :1;
//seccprocess.hlc_chargeparameterdiscoveryres
	 uint8_t hlc_cablecheckres :1; //seccprocess.hlc_cablecheckres *

     uint8_t hlc_prechargeres :1; //seccprocess.hlc_prechargeres *
     uint8_t hlc_powerdeliveryres :1; //seccprocess.hlc_powerdeliveryres
     uint8_t reserved8 :1;
     uint8_t hlc_currentdemandres :1; //seccprocess.hlc_currentdemandres
     uint8_t hlc_weldingdetectionres :1; //seccprocess.hlc_weldingdetectionres
     uint8_t hlc_sessionstopres :1; //seccprocess.hlc_sessionstopres
     uint8_t reserved9 :1;
     uint8_t reserved10 :1;

     uint8_t reserved11;
}hlc;




//  transmitting of message 5  -   0x08

typedef struct{//0x08
  uint16_t evmaximumvoltagelimit; //seccmsg5.evmaximumvoltagelimit
  uint16_t evenergycapacity; //seccmsg5.evenergycapacity
  uint16_t evenergyrequest; //seccmsg5.evenergyrequest
  uint8_t fullsoc; //seccmsg5.fullsoc
  uint8_t bulksoc; //seccmsg5.bulksoc
}msg5;


typedef struct{//0x09
 uint16_t remainingtimetofullsoc; //seccmsg6.remainingtimetofullsoc
 uint16_t remainingtimetobulksoc; //seccmsg6.remainingtimetobulksoc
 uint16_t evtargetvoltage; //seccmsg6.evtargetvoltage
 uint16_t evtargetcurrent; //seccmsg6.evtargetcurrent
}msg9;



typedef struct{//0x07
uint8_t evready :1; //seccmsg4.evready
uint8_t evcabinconditioning :1; //seccmsg4.evcabinconditioning
uint8_t evressconiditioning :1; //seccmsg4.evressconiditioning
uint8_t bulkchargingcomplete :1; //seccmsg4.bulkchargingcomplete
uint8_t chargingcomplete :1; //seccmsg4.chargingcomplete
uint8_t reserved :3;

uint8_t everrorcode; //seccmsg4.everrorcode
uint8_t evstatus_evresssoc; //seccmsg4.evstatus_evresssoc

uint16_t evmaximumcurrentlimit; //seccmsg4.evmaximumcurrentlimit
uint16_t evmaximumpowerlimit; //seccmsg4.evmaximumpowerlimit
uint8_t readytochargestate; //seccmsg4.readytochargestate
}msg4;


#endif /* inc_evsc_scr_h_ */
