/*/* user code begin header */
/**
  ******************************************************************************
  * @file    stm32f4xx_it.c
  * @brief   interrupt service routines.
  ******************************************************************************
  * @attention
  *
  * copyright (c) 2024 stmicroelectronics.
  * all rights reserved.
  *
  * this software is licensed under terms that can be found in the license file
  * in the root directory of this software component.
  * if no license file comes with this software, it is provided as-is.
  *
  ******************************************************************************
  */
/* user code end header */

/* includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f4xx_it.h"
/* private includes ----------------------------------------------------------*/
/* user code begin includes */

#include<stdint.h>

#include<evsc-scr.h>
#include<main.h>
#include<stdio.h>
#include<stdint.h>
#include<math.h>

/* user code end includes */

/* private typedef -----------------------------------------------------------*/
/* user code begin td */

/* user code end td */

/* private define ------------------------------------------------------------*/
/* user code begin pd */

/* user code end pd */

/* private macro -------------------------------------------------------------*/
/* user code begin pm */

/* user code end pm */

/* private variables ---------------------------------------------------------*/
/* user code begin pv */
extern uint64_t inc_evsc_com;
extern uint64_t secc_set_com;

pwm pwm_mes;
evsepwm pwm_evse;
msg1 msg1evsc;
msg4 secc_msg4;
hlc auth;
msg5 volt;
msg5 secc_msg5;

/* user code end pv */

/* private function prototypes -----------------------------------------------*/
/* user code begin pfp */

/* user code end pfp */

/* private user code ---------------------------------------------------------*/
/* user code begin 0 */

void pwmdata(uint64_t secc_set_com) // seccpwminfo to evse
{

	pwm_mes.seccpwmduty= (secc_set_com >> 0) & 0xff; // extracting the first 8 bit
	pwm_mes.seccpwmfrequency = (secc_set_com >> 8) & 0xffff; // next 16 bit
	pwm_mes.seccpwmvoltage  =(secc_set_com>>24) & 0xffff; // next 16 bit
	pwm_mes.reserved3=(secc_set_com >> 32) & 0xff;
	pwm_mes.reserved4=(secc_set_com >> 40) & 0xff;
	pwm_mes.reserved5=(secc_set_com >> 48) & 0xff;
}


void pwmdataevse(uint64_t inc_evsc_com) // seccpwminfo to evse
{

	pwm_evse.evsepwmduty =(inc_evsc_com >> 0) & 0xff; //evsepwminfo.evsepwmduty
	pwm_evse.evsepwmfrequency = (inc_evsc_com >> 8) & 0xffff; //evsepwminfo.evsepwmfrequency
	pwm_evse.evsepwmvoltage =(inc_evsc_com>>24) & 0xffff; //evsepwminfo.evsepwmvoltage
	pwm_evse.reserved3 = (inc_evsc_com >> 32) & 0xff;
	pwm_evse.reserved4 =(inc_evsc_com >> 40) & 0xff;
	pwm_evse.reserved5 =(inc_evsc_com >> 48) & 0xff;

}


void msg1_evsc(uint64_t inc_evsc_com)
{

	msg1evsc.evseprocessing_authentication =(inc_evsc_com >> 0) & 0x1;
	msg1evsc.evseprocessing_chargeparam= (inc_evsc_com >> 1) & 0x1;
	msg1evsc.evseprocessing_cablecheck =(inc_evsc_com >> 2) & 0x1;
	msg1evsc.reserved=(inc_evsc_com >> 3) & 0x1f;
	msg1evsc.evseisolationstatus=(inc_evsc_com >> 8) & 0xff;
	msg1evsc.evsestatuscode = (inc_evsc_com >> 16) & 0xff;  // byte 3
	msg1evsc.reserved4= (inc_evsc_com >> 24) & 0xffffffff;

}


// for setting the athentication process

hlc auth;

void authentication (uint64_t inc_evsc_com)
{
	auth.comm_slac = (inc_evsc_com >> 0) & 0x1;
	auth.comm_sdp = (inc_evsc_com >> 1) & 0x1;
	auth.reserved = (inc_evsc_com >> 2) & 0x3f;

	auth.hlc_supportedappprotocolreq = (inc_evsc_com >> 8) & 0x1;
	auth.hlc_sessionsetupreq = (inc_evsc_com >> 9) & 0x1;
	auth.hlc_sevicediscoveryreq = (inc_evsc_com >> 10) & 0x1;
	auth.reserved2 = (inc_evsc_com >> 11) & 0x1;
	auth.hlc_servicepaymentselectionreq= (inc_evsc_com >> 12) & 0x1;
	auth.hlc_contractauthenticationreq = (inc_evsc_com >> 13) & 0x1;
	auth.hlc_chargeparameterdiscoveryreq = (inc_evsc_com >> 14) & 0x1;

	auth.hlc_cablecheckreq = (inc_evsc_com >> 15) & 0x1;

	auth.hlc_prechargereq= (inc_evsc_com >> 16) & 0x1;
	auth.hlc_powerdeliveryreq = (inc_evsc_com >> 17) & 0x1;
	auth.reserved3 = (inc_evsc_com >> 18) & 0x1;
	auth.hlc_currentdemandreq = (inc_evsc_com >> 19) & 0x1;
	auth.hlc_weldingdetectionreq = (inc_evsc_com >> 20) & 0x1;
	auth.hlc_sessionstopreq = (inc_evsc_com >> 21) & 0x1;
	auth.reserved4 = (inc_evsc_com >> 22) & 0x1;
	auth.reserved5= (inc_evsc_com >> 23) & 0x1;

	auth.reserve6 = (inc_evsc_com >> 24) & 0xff;

	auth.hlc_supportedappprotocolres = (inc_evsc_com >> 32) & 0x1;
	auth.hlc_sessionsetupres = (inc_evsc_com >> 33) & 0x1;
	auth.hlc_sevicediscoveryres = (inc_evsc_com >> 34) & 0x1;
	auth.reserved7 = (inc_evsc_com >> 35) & 0x1;
	auth.hlc_servicepaymentselectionres = (inc_evsc_com >> 36) & 0x1;
	auth.hlc_contractauthenticationres = (inc_evsc_com >> 37) & 0x1;
	auth.hlc_chargeparameterdiscoveryres = (inc_evsc_com >> 38) & 0x1;
	auth.hlc_cablecheckres = (inc_evsc_com >> 39) & 0x1;

	auth.hlc_prechargeres = (inc_evsc_com >> 40) & 0x1;
	auth.hlc_powerdeliveryres = (inc_evsc_com >> 41) & 0x1;
	auth.reserved8 = (inc_evsc_com >> 42) & 0x1;
	auth.hlc_currentdemandres = (inc_evsc_com >> 43) & 0x1;
	auth.hlc_weldingdetectionres = (inc_evsc_com >> 44) & 0x1;
	auth.hlc_sessionstopres = (inc_evsc_com >> 45) & 0x1;
	auth.reserved9 = (inc_evsc_com >> 46) & 0x1;
	auth.reserved10 = (inc_evsc_com >> 47) & 0x1;

	auth.reserved11 = (inc_evsc_com >> 48) & 0xff;

}


// sending of the messsage to the evse

msg5 volt;
void mess5th(uint64_t secc_set_com)
{
	volt.evmaximumvoltagelimit  = (secc_set_com >> 0) & 0xffff;
	volt.evenergycapacity=(secc_set_com >> 16) & 0xffff;
	volt.evenergyrequest=(secc_set_com >> 32) & 0xffff;
	volt.fullsoc=(secc_set_com >> 40) & 0xff;
	volt.bulksoc= (secc_set_com >> 48) & 0xff;
}

msg9 tx9thmsg;

void txmsg9(uint64_t secc_set_com)
{
	tx9thmsg.remainingtimetofullsoc = (secc_set_com >> 0) & 0xffff;
	tx9thmsg.remainingtimetobulksoc = (secc_set_com >> 16) & 0xffff;
	tx9thmsg.evtargetvoltage = (secc_set_com >> 32) & 0xffff;
	tx9thmsg.evtargetcurrent= (secc_set_com >> 48) & 0xffff;
}
void maxvolt(uint64_t inc_evsc_com)
{
secc_msg5.evmaximumvoltagelimit = (inc_evsc_com >> 0) & 0xffff;
secc_msg5.evenergycapacity = (inc_evsc_com >> 16) & 0xffff;
secc_msg5.evenergyrequest = (inc_evsc_com >> 32) & 0xffff;
secc_msg5.fullsoc = (inc_evsc_com >> 48) & 0xff;
secc_msg5.bulksoc = (inc_evsc_com >> 56) & 0xff;
}

void evready(uint64_t inc_evsc_com)    //0x07
{
secc_msg4.evready = (inc_evsc_com >> 0) & 0x1;
secc_msg4.evcabinconditioning = (inc_evsc_com >> 1) & 0x1;
secc_msg4.evressconiditioning = (inc_evsc_com >> 2) & 0x1;
secc_msg4.bulkchargingcomplete = (inc_evsc_com >> 3) & 0x1;
secc_msg4.chargingcomplete = (inc_evsc_com >> 4) & 0x1;
secc_msg4.reserved = (inc_evsc_com >> 5) & 0x7;

secc_msg4.everrorcode = (inc_evsc_com >> 8) & 0xff;
secc_msg4.evstatus_evresssoc = (inc_evsc_com >> 16) & 0xff;

secc_msg4.evmaximumcurrentlimit = (inc_evsc_com >> 24) & 0xffff;
secc_msg4.evmaximumpowerlimit = (inc_evsc_com >> 40) & 0xffff;
secc_msg4.readytochargestate = (inc_evsc_com >> 56) & 0xff;
}


/*


 uint64_t rx_data; // incoming data

evse_info_t evse_info;

// extracting fields
evse_info.evseheartbeat = (rx_data >> 0) & 0xff;
evse_info.evseactive = (rx_data >> 8) & 0x1;
evse_info.reserved = (rx_data >> 9) & 0x7f;

evse_info.seccpwmenablereq = (rx_data >> 16) & 0x1;
evse_info.seccinitalizereq = (rx_data >> 17) & 0x1;
evse_info.reserved2 = (rx_data >> 18) & 0x3f;

evse_info.reserved3 = (rx_data >> 24) & 0xff;
evse_info.reserved4 = (rx_data >> 32) & 0xff;
evse_info.reserved5 = (rx_data >> 40) & 0xff;
evse_info.evseidlength = (rx_data >> 48) & 0xff;
evse_info.reserved7 = (rx_data >> 56) & 0xff;




 evse_pwm_info_t evse_pwm_info;

// extracting fields
evse_pwm_info.evsepwmduty = (rx_data >> 0) & 0xff;
evse_pwm_info.evsepwmfrequency = (rx_data >> 8) & 0xffff;
evse_pwm_info.evsepwmvoltage = (rx_data >> 24) & 0xffff;

evse_pwm_info.reserved3 = (rx_data >> 40) & 0xff;
evse_pwm_info.reserved4 = (rx_data >> 48) & 0xff;
evse_pwm_info.reserved5 = (rx_data >> 56) & 0xff;




 evse_msg1_t evse_msg1;

// extracting fields
evse_msg1.evseprocessing_authentication = (rx_data >> 0) & 0x1;
evse_msg1.evseprocessing_chargeparam = (rx_data >> 1) & 0x1;
evse_msg1.evseprocessing_cablecheck = (rx_data >> 2) & 0x1;
evse_msg1.reserved = (rx_data >> 3) & 0x1f;

evse_msg1.evseisolationstatus = (rx_data >> 8) & 0xff;
evse_msg1.evsestatuscode = (rx_data >> 16) & 0xff;

evse_msg1.reserved4 = (rx_data >> 24) & 0xffffffff;



evse_msg3_t evse_msg3;

// extracting fields
evse_msg3.evsemaximumcurrentlimit = (rx_data >> 0) & 0xffff;
evse_msg3.evsemaximumpowerlimit = (rx_data >> 16) & 0xffff;
evse_msg3.evsemaximumvoltagelimit = (rx_data >> 32) & 0xffff;
evse_msg3.evseminimumcurrentlimit = (rx_data >> 48) & 0xffff;





evse_msg4_t evse_msg4;

// extracting fields
evse_msg4.evseminimumvoltagelimit = (rx_data >> 0) & 0xffff;
evse_msg4.evsecurrentregulationtolerance = (rx_data >> 16) & 0xffff;
evse_msg4.evsepeakcurrentripple = (rx_data >> 32) & 0xffff;
evse_msg4.evseenergytobedelivered = (rx_data >> 48) & 0xffff;




evse_msg5_t evse_msg5;

// extracting fields
evse_msg5.evsepresentvoltage = (rx_data >> 0) & 0xffff;
evse_msg5.evsepresentcurrent = (rx_data >> 16) & 0xffff;

evse_msg5.evsecurrentlimitachieved = (rx_data >> 32) & 0x1;
evse_msg5.evsevoltagelimitachieved = (rx_data >> 33) & 0x1;
evse_msg5.evsepowerlimitachieved = (rx_data >> 34) & 0x1;
evse_msg5.reserved = (rx_data >> 35) & 0x1f;

evse_msg5.reserved2 = (rx_data >> 40) & 0xff;
evse_msg5.reserved3 = (rx_data >> 48) & 0xff;
evse_msg5.reserved4 = (rx_data >> 56) & 0xff;






// here comes the data for secc


 uint64_t rx_data;
secc_status_t secc_status;

// extracting fields from rx_data
secc_status.seccheartbeat = (rx_data >> 0) & 0xff;

secc_status.seccactive = (rx_data >> 8) & 0x1;
secc_status.seccpwmsupport = (rx_data >> 9) & 0x1;
secc_status.reserved = (rx_data >> 10) & 0x1;
secc_status.secchpgpsleepstatus = (rx_data >> 11) & 0x1;
secc_status.seccfirmwareupdatestate = (rx_data >> 12) & 0xf;

secc_status.seccchargingstate = (rx_data >> 16) & 0xf;
secc_status.reserved2 = (rx_data >> 20) & 0xf;

secc_status.seccversionmajor = (rx_data >> 24) & 0xff;
secc_status.seccversionminor = (rx_data >> 32) & 0xff;
secc_status.seccversionpatch = (rx_data >> 40) & 0xff;
secc_status.seccstatuscode = (rx_data >> 48) & 0xff;
secc_status.reserved3 = (rx_data >> 56) & 0xff;



 secc_pwm_info_t secc_pwm_info;

// extracting fields
secc_pwm_info.seccpwmduty = (rx_data >> 0) & 0xff;
secc_pwm_info.seccpwmfrequency = (rx_data >> 8) & 0xffff;
secc_pwm_info.seccpwmvoltage = (rx_data >> 24) & 0xffff;

secc_pwm_info.reserved3 = (rx_data >> 40) & 0xff;
secc_pwm_info.reserved4 = (rx_data >> 48) & 0xff;
secc_pwm_info.reserved5 = (rx_data >> 56) & 0xff;




 secc_process_t secc_process;

// extracting fields
secc_process.comm_slac = (rx_data >> 0) & 0x1;
secc_process.comm_sdp = (rx_data >> 1) & 0x1;
secc_process.reserved = (rx_data >> 2) & 0x3f;

secc_process.hlc_supportedappprotocolreq = (rx_data >> 8) & 0x1;
secc_process.hlc_sessionsetupreq = (rx_data >> 9) & 0x1;
secc_process.hlc_sevicediscoveryreq = (rx_data >> 10) & 0x1;
secc_process.reserved2 = (rx_data >> 11) & 0x1;
secc_process.hlc_servicepaymentselectionreq = (rx_data >> 12) & 0x1;
secc_process.hlc_contractauthenticationreq = (rx_data >> 13) & 0x1;
secc_process.hlc_chargeparameterdiscoveryreq = (rx_data >> 14) & 0x1;
secc_process.hlc_cablecheckreq = (rx_data >> 15) & 0x1;

secc_process.hlc_prechargereq = (rx_data >> 16) & 0x1;
secc_process.hlc_powerdeliveryreq = (rx_data >> 17) & 0x1;
secc_process.reserved3 = (rx_data >> 18) & 0x1;
secc_process.hlc_currentdemandreq = (rx_data >> 19) & 0x1;
secc_process.hlc_weldingdetectionreq = (rx_data >> 20) & 0x1;
secc_process.hlc_sessionstopreq = (rx_data >> 21) & 0x1;
secc_process.reserved4 = (rx_data >> 22) & 0x1;
secc_process.reserved5 = (rx_data >> 23) & 0x1;

secc_process.reserve6 = (rx_data >> 24) & 0xff;

secc_process.hlc_supportedappprotocolres = (rx_data >> 32) & 0x1;
secc_process.hlc_sessionsetupres = (rx_data >> 33) & 0x1;
secc_process.hlc_sevicediscoveryres = (rx_data >> 34) & 0x1;
secc_process.reserved7 = (rx_data >> 35) & 0x1;
secc_process.hlc_servicepaymentselectionres = (rx_data >> 36) & 0x1;
secc_process.hlc_contractauthenticationres = (rx_data >> 37) & 0x1;
secc_process.hlc_chargeparameterdiscoveryres = (rx_data >> 38) & 0x1;
secc_process.hlc_cablecheckres = (rx_data >> 39) & 0x1;

secc_process.hlc_prechargeres = (rx_data >> 40) & 0x1;
secc_process.hlc_powerdeliveryres = (rx_data >> 41) & 0x1;
secc_process.reserved8 = (rx_data >> 42) & 0x1;
secc_process.hlc_currentdemandres = (rx_data >> 43) & 0x1;
secc_process.hlc_weldingdetectionres = (rx_data >> 44) & 0x1;
secc_process.hlc_sessionstopres = (rx_data >> 45) & 0x1;
secc_process.reserved9 = (rx_data >> 46) & 0x1;
secc_process.reserved10 = (rx_data >> 47) & 0x1;

secc_process.reserved11 = (rx_data >> 48) & 0xff;




secc_msg1_t secc_msg1;

// extracting fields
for (int i = 0; i < 8; i++) {
    secc_msg1.evccid[i] = (rx_data >> (i * 8)) & 0xff;
}




secc_msg2_t secc_msg2;

// extracting fields
secc_msg2.evccidlength = (rx_data >> 0) & 0xff;
secc_msg2.servicecategory = (rx_data >> 8) & 0xff;
secc_msg2.evrequestedenergytransfertype = (rx_data >> 16) & 0xff;





secc_msg3_t secc_msg3;

// extracting fields
secc_msg3.eselectedpaymentoption = (rx_data >> 0) & 0xff;
secc_msg3.reserved = (rx_data >> 8) & 0xffff;
secc_msg3.reserved2 = (rx_data >> 24) & 0xffff;
secc_msg3.reserved3 = (rx_data >> 40) & 0xffff;
secc_msg3.reserved4 = (rx_data >> 56) & 0xff;





secc_msg4_t secc_msg4;

// extracting fields
secc_msg4.evready = (rx_data >> 0) & 0x1;
secc_msg4.evcabinconditioning = (rx_data >> 1) & 0x1;
secc_msg4.evressconiditioning = (rx_data >> 2) & 0x1;
secc_msg4.bulkchargingcomplete = (rx_data >> 3) & 0x1;
secc_msg4.chargingcomplete = (rx_data >> 4) & 0x1;
secc_msg4.reserved = (rx_data >> 5) & 0x7;

secc_msg4.everrorcode = (rx_data >> 8) & 0xff;
secc_msg4.evstatus_evresssoc = (rx_data >> 16) & 0xff;

secc_msg4.evmaximumcurrentlimit = (rx_data >> 24) & 0xffff;
secc_msg4.evmaximumpowerlimit = (rx_data >> 40) & 0xffff;
secc_msg4.readytochargestate = (rx_data >> 56) & 0xff;


secc_msg5_t secc_msg5;

// extracting fields from the 64-bit data
secc_msg5.evmaximumvoltagelimit = (rx_data >> 0) & 0xffff;
secc_msg5.evenergycapacity = (rx_data >> 16) & 0xffff;
secc_msg5.evenergyrequest = (rx_data >> 32) & 0xffff;
secc_msg5.fullsoc = (rx_data >> 48) & 0xff;
secc_msg5.bulksoc = (rx_data >> 56) & 0xff;



secc_msg6_t secc_msg6;

// extracting fields from the 64-bit data
secc_msg6.remainingtimetofullsoc = (rx_data >> 0) & 0xffff;
secc_msg6.remainingtimetobulksoc = (rx_data >> 16) & 0xffff;
secc_msg6.evtargetvoltage = (rx_data >> 32) & 0xffff;
secc_msg6.evtargetcurrent = (rx_data >> 48) & 0xffff;




/* user code end 0 */

/******************************************************************************/
/*           cortex-m4 processor interruption and exception handlers          */
/******************************************************************************/
/**
  * @brief this function handles non maskable interrupt.
  */

/* user code begin 1 */

/* user code end 1 */
