/*
 * BMS_C.C
 *
 *  Created on: Dec 11, 2024
 *      Author: HARITHA
 */



//#include"main.h"
//#include"BMS_C.h"
//
//
//
//extern uint8_t  contactor,SoC,tmin;
//extern uint16_t pVoltage,pCurrent,pTemperature;
//
//extern uint8_t hr,min;
//extern uint16_t final_pVoltage,final_pCurrent,final_pTemperature;
//








