/*
 * BMS_C.h
 *
 *  Created on: Dec 11, 2024
 *      Author: HARITHA
 */



#ifndef INC_BMS_C_H_
#define INC_BMS_C_H_



void data_float(void);

#endif /* INC_BMS_C_H_ */
